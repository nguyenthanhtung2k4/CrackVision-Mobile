from fastapi import APIRouter, UploadFile, File, HTTPException
from app.database import get_db
from app.services.face_service import extract_embedding, identify_face
from app.services.locker_service import update_locker_status, open_locker
import pickle
import datetime

router = APIRouter()

@router.post("/reserve")
def reserve_locker(locker_id: int = 1, hours: int = 2):
    conn = get_db()
    locker = conn.execute("SELECT * FROM lockers WHERE id = ?", (locker_id,)).fetchone()
    if locker is None or locker["status"] != "AVAILABLE":
        conn.close()
        raise HTTPException(400, "Ngăn không khả dụng")
    end_time = datetime.datetime.now() + datetime.timedelta(hours=hours)
    conn.execute("INSERT INTO rentals (locker_id, end_time, status, price) VALUES (?, ?, 'RESERVED', ?)",
                 (locker_id, end_time, hours * 10000))
    rental_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.commit()
    conn.close()
    update_locker_status(locker_id, "RESERVED")
    return {"rental_id": rental_id, "locker_id": locker_id, "timeout": 120}

@router.post("/upload-face/{rental_id}")
async def upload_face(rental_id: int, file: UploadFile = File(...)):
    contents = await file.read()
    embedding = extract_embedding(contents)
    if embedding is None:
        raise HTTPException(400, "Không tìm thấy khuôn mặt")
    embedding_blob = pickle.dumps(embedding)
    conn = get_db()
    conn.execute("INSERT OR REPLACE INTO face_embeddings_active (rental_id, embedding) VALUES (?, ?)",
                 (rental_id, embedding_blob))
    conn.commit()
    conn.close()
    return {"status": "ok"}

@router.post("/payment/callback")
def payment_callback(rental_id: int):
    conn = get_db()
    rental = conn.execute("SELECT * FROM rentals WHERE id = ?", (rental_id,)).fetchone()
    if rental is None or rental["status"] != "RESERVED":
        conn.close()
        raise HTTPException(400, "Giao dịch không hợp lệ")
    locker_id = rental["locker_id"]
    conn.execute("UPDATE rentals SET status = 'OCCUPIED' WHERE id = ?", (rental_id,))
    conn.commit()
    conn.close()
    update_locker_status(locker_id, "OCCUPIED")
    open_locker(locker_id)
    return {"status": "ok"}

@router.post("/identify")
async def identify(file: UploadFile = File(...)):
    contents = await file.read()
    embedding = extract_embedding(contents)
    if embedding is None:
        raise HTTPException(400, "Không tìm thấy khuôn mặt")
    rental_id = identify_face(embedding)
    if rental_id is None:
        raise HTTPException(401, "Khuôn mặt không khớp")
    conn = get_db()
    rental = conn.execute("SELECT * FROM rentals WHERE id = ?", (rental_id,)).fetchone()
    conn.close()
    return {
        "rental_id": rental_id,
        "locker_id": rental["locker_id"],
        "status": rental["status"],
        "time_left": str(rental["end_time"] - datetime.datetime.now())
    }

@router.post("/temp-open")
def temp_open(rental_id: int):
    conn = get_db()
    rental = conn.execute("SELECT * FROM rentals WHERE id = ?", (rental_id,)).fetchone()
    if rental is None or rental["status"] not in ("OCCUPIED", "OVERTIME"):
        conn.close()
        raise HTTPException(400, "Không thể mở tạm thời")
    locker_id = rental["locker_id"]
    conn.close()
    open_locker(locker_id)
    return {"status": "ok"}

@router.post("/return")
def return_locker(rental_id: int):
    conn = get_db()
    rental = conn.execute("SELECT * FROM rentals WHERE id = ?", (rental_id,)).fetchone()
    if rental is None or rental["status"] not in ("OCCUPIED", "OVERTIME"):
        conn.close()
        raise HTTPException(400, "Trạng thái thuê không hợp lệ")
    locker_id = rental["locker_id"]
    conn.execute("UPDATE rentals SET status = 'COMPLETED' WHERE id = ?", (rental_id,))
    emb_row = conn.execute("SELECT * FROM face_embeddings_active WHERE rental_id = ?", (rental_id,)).fetchone()
    if emb_row:
        conn.execute("INSERT INTO face_embeddings_history (rental_id, embedding) VALUES (?, ?)",
                     (rental_id, emb_row["embedding"]))
        conn.execute("DELETE FROM face_embeddings_active WHERE rental_id = ?", (rental_id,))
    conn.commit()
    conn.close()
    open_locker(locker_id)
    update_locker_status(locker_id, "AVAILABLE")
    return {"status": "ok"}