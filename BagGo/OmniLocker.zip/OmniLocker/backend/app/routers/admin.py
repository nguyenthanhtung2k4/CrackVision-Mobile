from fastapi import APIRouter, HTTPException
from app.database import get_db
from app.services.locker_service import open_locker, close_locker, update_locker_status

router = APIRouter()

@router.post("/admin/open")
def admin_open(locker_id: int = 1):
    update_locker_status(locker_id, "ADMIN_INTERVENTION")
    open_locker(locker_id)
    return {"status": "admin_open"}

@router.post("/admin/close")
def admin_close(locker_id: int = 1):
    conn = get_db()
    locker = conn.execute("SELECT * FROM lockers WHERE id = ?", (locker_id,)).fetchone()
    conn.close()
    if locker is None:
        raise HTTPException(404, "Không tìm thấy ngăn")
    close_locker(locker_id)
    update_locker_status(locker_id, "OCCUPIED")
    return {"status": "admin_close"}

@router.post("/admin/force-return")
def force_return(locker_id: int = 1):
    conn = get_db()
    rental = conn.execute("SELECT * FROM rentals WHERE locker_id = ? AND status IN ('OCCUPIED','OVERTIME')",
                          (locker_id,)).fetchone()
    if rental is None:
        conn.close()
        raise HTTPException(400, "Không có người thuê")
    rental_id = rental["id"]
    conn.execute("UPDATE rentals SET status = 'COMPLETED' WHERE id = ?", (rental_id,))
    emb_row = conn.execute("SELECT * FROM face_embeddings_active WHERE rental_id = ?", (rental_id,)).fetchone()
    if emb_row:
        conn.execute("INSERT INTO face_embeddings_history (rental_id, embedding) VALUES (?, ?)",
                     (rental_id, emb_row["embedding"]))
        conn.execute("DELETE FROM face_embeddings_active WHERE rental_id = ?", (rental_id,))
    conn.commit()
    conn.close()
    open_locker(locker_id)
    update_locker_status(locker_id, "AVAILABLE")
    return {"status": "force_return"}