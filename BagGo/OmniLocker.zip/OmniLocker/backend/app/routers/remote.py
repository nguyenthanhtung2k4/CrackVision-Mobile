from fastapi import APIRouter, UploadFile, File, HTTPException
from app.services.face_service import extract_embedding, identify_face
from app.database import get_db
import paho.mqtt.publish as publish
import datetime

router = APIRouter()

@router.post("/remote/identify")
async def remote_identify(file: UploadFile = File(...)):
    contents = await file.read()
    embedding = extract_embedding(contents)
    if embedding is None:
        raise HTTPException(400, "Không tìm thấy khuôn mặt")
    rental_id = identify_face(embedding)
    if rental_id is None:
        raise HTTPException(401, "Không tìm thấy thông tin thuê")
    conn = get_db()
    rental = conn.execute("SELECT * FROM rentals WHERE id = ?", (rental_id,)).fetchone()
    conn.close()
    return {
        "locker_id": rental["locker_id"],
        "time_left": str(rental["end_time"] - datetime.datetime.now()),
        "status": rental["status"]
    }

@router.post("/remote/blink/{locker_id}")
def remote_blink(locker_id: int):
    publish.single(f"locker/{locker_id}/led", "BLINK_BOTH", hostname="localhost")
    return {"status": "blinking"}