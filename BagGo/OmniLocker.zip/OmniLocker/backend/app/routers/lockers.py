from fastapi import APIRouter
from app.database import get_db

router = APIRouter()

@router.get("/lockers")
def get_lockers():
    conn = get_db()
    rows = conn.execute("SELECT * FROM lockers").fetchall()
    conn.close()
    return [dict(row) for row in rows]