import paho.mqtt.publish as publish
from app.database import get_db
from app.websocket_manager import manager
import json
import asyncio

MQTT_HOST = "localhost"

def update_locker_status(locker_id: int, new_status: str):
    conn = get_db()
    conn.execute("UPDATE lockers SET status = ? WHERE id = ?", (new_status, locker_id))
    conn.commit()
    conn.close()

    led_map = {
        "AVAILABLE": "GREEN",
        "OCCUPIED": "RED",
        "OVERTIME": "BLINK_RED",
        "RESERVED": "BLINK_GREEN",
        "ADMIN_INTERVENTION": "BLINK_BOTH"
    }
    led_mode = led_map.get(new_status, "RED")
    publish.single(f"locker/{locker_id}/led", led_mode, hostname=MQTT_HOST)

    asyncio.run(manager.broadcast(json.dumps({
        "type": "locker_update",
        "locker_id": locker_id,
        "status": new_status
    })))

def open_locker(locker_id: int):
    publish.single(f"locker/{locker_id}/open", "", hostname=MQTT_HOST)

def close_locker(locker_id: int):
    publish.single(f"locker/{locker_id}/close", "", hostname=MQTT_HOST)