import numpy as np
import cv2
import pickle
from deepface import DeepFace

def extract_embedding(image_bytes: bytes):
    """Nhận ảnh dạng bytes, trả về embedding (list 128 số) hoặc None"""
    try:
        nparr = np.frombuffer(image_bytes, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        if img is None:
            return None
        rgb_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        embedding_objs = DeepFace.represent(
            img_path=rgb_img,
            model_name='Facenet512',
            enforce_detection=False,
            detector_backend='opencv'
        )
        if not embedding_objs:
            return None
        return embedding_objs[0]['embedding']
    except Exception as e:
        print("extract_embedding error:", e)
        return None

def identify_face(embedding):
    from app.database import get_db
    conn = get_db()
    rows = conn.execute("""
        SELECT fa.rental_id, fa.embedding
        FROM face_embeddings_active fa
        JOIN rentals r ON fa.rental_id = r.id
        WHERE r.status IN ('OCCUPIED', 'OVERTIME')
    """).fetchall()
    conn.close()

    if not rows:
        return None

    query_emb = np.array(embedding)
    best_distance = float('inf')
    best_rental_id = None

    for row in rows:
        stored_embedding = pickle.loads(row["embedding"])
        stored_emb = np.array(stored_embedding)
        distance = np.linalg.norm(stored_emb - query_emb)
        if distance < best_distance:
            best_distance = distance
            best_rental_id = row["rental_id"]

    # Ngưỡng Euclidean < 10.0 (tương đương cosine similarity ~ 0.3)
    if best_distance < 10.0:
        return best_rental_id
    return None